import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./QuestionPage.css";
const QuestionsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const files = location.state?.files || [];

  const handleContinue = () => {
    navigate("/third-page", { state: { files } });
  };

  return (
    <div className="questions-page">
      <div className="side-panel">
        <button className="back-button" onClick={() => navigate("/")}>
          Back to home
        </button>
        <div className="given-information">
          <h4>Given Information</h4>
          <p>Text Entered</p>
          <p>
            I'm researching environmental regulations. Can you summarize the
            Clean Air Act and its objectives with details.
          </p>
          <div className="uploaded-files">
            <h4>Uploaded files {files.length}/5</h4>
            <ul>
              {files.map((file, index) => (
                <li key={index}>{file.name}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <div className="questions-section">
        <h3>Questions</h3>
        <div className="questions-nav">
          <button>By Petitioner</button>
          <button>By Respondent</button>
        </div>
        <div className="questions-list">
          <h4>
            1. Was the dog on a leash or under the control of the owner at the
            time of the incident?
          </h4>
          <p>
            Reason - This question aims to establish whether the owner was
            negligent in controlling the dog, which is crucial for proving
            liability.
          </p>
          <h4>
            2. Did the dog show any signs of aggression or previous violent
            behaviour before the incident
          </h4>

          <p>
            Reason- This question is important to demonstrate the owner's
            knowledge of the dog's aggressive tendencies, which can support the
            claim of negligence.
          </p>
          <h4>
            3. Were there any warning signs or notices indicates the presence of
            a dangerous dog on the owner's property?
          </h4>
          <p>
            Reason- this question seeks to determine if the owner took
            reasonable precautions to warm others about the potential danger
            posed by the dog
          </p>
          <h4>
            4. Has the dog been involved in similar incidents of biting or
            aggression in the past?
          </h4>
          <p>
            Reason- This question is relevant to establish a pattern of
            behaviour and the owrier's awareness of the dog's propensity for
            aggression
          </p>
          <h4>
            5. Did the owner take immediate steps to assist or provide medical
            aid to the victim after the dog bite incident?
          </h4>
          <p>
            Reason- This question addresses the owner's duty of care and
            responsibility towards the victim following the incident
          </p>
          <h4>
            6. Can you provide any evidence of communication or interaction with
            the owner regarding the dog's behaviour prior to the incident?
          </h4>
          <p>Reason-</p>
        </div>
      </div>
      <button className="continue-button" onClick={handleContinue}>
        Continue
      </button>
    </div>
  );
};

export default QuestionsPage;
